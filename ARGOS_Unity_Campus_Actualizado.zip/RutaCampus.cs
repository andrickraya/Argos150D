using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
#if UNITY_EDITOR
using System.Linq;
using UnityEditor;
#endif

/// <summary>
/// Marca un campo de texto para que se muestre como lista desplegable con los lugares del campus.
/// </summary>
public class LugarCampusAttribute : PropertyAttribute { }

/// <summary>
/// Calcula la ruta más corta con el NavMesh y la dibuja en la vista Scene.
///  - Sin "Usuario": ruta fija entre dos lugares (Origen → Destino).
///  - Con "Usuario": la ruta sale de la posición del usuario, se recalcula sola mientras camina
///    y avisa cuando llega al destino. (En el visor, "Usuario" será la cabeza del usuario.)
/// Requiere en la escena: un objeto con CampusPOIs y un NavMesh ya horneado (CampusNav).
/// </summary>
public class RutaCampus : MonoBehaviour
{
    [Header("Referencias")]
    [Tooltip("Objeto Campus (el que tiene el script CampusPOIs). Si se deja vacío se busca solo.")]
    public CampusPOIs campus;

    [Header("Ruta")]
    [Tooltip("Solo se usa si no hay Usuario asignado.")]
    [LugarCampus] public string origen = "Puerta 3";
    [LugarCampus] public string destino = "La Karpa";

    [Header("Seguimiento del usuario (opcional)")]
    [Tooltip("Si se asigna, la ruta sale de este objeto y se actualiza sola mientras se mueve.")]
    public Transform usuario;
    [Tooltip("Cada cuántos segundos se revisa si hay que recalcular.")]
    public float intervaloRecalculo = 0.5f;
    [Tooltip("Metros que debe moverse el usuario para recalcular.")]
    public float distanciaMinima = 1f;
    [Tooltip("A cuántos metros (por el camino) del destino se considera que llegó.")]
    public float radioLlegada = 4f;

    [Header("Ajustes")]
    [Tooltip("Distancia máxima (m) para buscar el punto caminable más cercano a un lugar. Útil cuando el lugar queda dentro de un edificio.")]
    public float radioBusqueda = 40f;
    [Tooltip("Velocidad al caminar (m/s) para estimar el tiempo.")]
    public float velocidadCaminata = 1.4f;
    public bool calcularAlIniciar = true;

    readonly List<Vector3> esquinas = new List<Vector3>();
    float temporizador;
    Vector3 ultimaPosUsuario;
    string ultimoDestino;
    bool forzarRecalculo;

    /// <summary>Se dispara una vez cuando el usuario llega al destino.</summary>
    public event System.Action Llegada;

    /// <summary>True cuando el usuario ya llegó al destino (solo con Usuario asignado).</summary>
    public bool HaLlegado { get; private set; }

    /// <summary>Puntos de giro de la ruta calculada (del origen/usuario al destino).</summary>
    public IReadOnlyList<Vector3> Esquinas { get { return esquinas; } }

    /// <summary>Longitud total de la ruta en metros.</summary>
    public float Longitud
    {
        get
        {
            float total = 0f;
            for (int i = 1; i < esquinas.Count; i++) total += Vector3.Distance(esquinas[i - 1], esquinas[i]);
            return total;
        }
    }

    /// <summary>Metros que faltan para llegar (la ruta siempre empieza en el usuario).</summary>
    public float DistanciaRestante { get { return Longitud; } }

    void Start()
    {
        ultimoDestino = destino;
        if (calcularAlIniciar) Calcular();
    }

    void Update()
    {
        if (usuario == null) return;

        if (destino != ultimoDestino)            // cambió el destino: empezar de nuevo
        {
            ultimoDestino = destino;
            HaLlegado = false;
            forzarRecalculo = true;
        }
        if (HaLlegado) return;

        temporizador -= Time.deltaTime;
        if (temporizador > 0f) return;
        temporizador = intervaloRecalculo;

        if (!forzarRecalculo && esquinas.Count > 0 &&
            Vector3.Distance(usuario.position, ultimaPosUsuario) < distanciaMinima) return;

        forzarRecalculo = false;
        CalcularDesde(usuario.position);
    }

    /// <summary>Calcula la ruta ahora. También se puede lanzar con clic derecho en el título del componente.</summary>
    [ContextMenu("Calcular ruta")]
    public bool Calcular()
    {
        Vector3 desde;
        if (usuario != null) desde = usuario.position;
        else if (!TryGetLugar(origen, out desde)) { esquinas.Clear(); return false; }
        return CalcularDesde(desde);
    }

    bool CalcularDesde(Vector3 desde)
    {
        esquinas.Clear();

        Vector3 hasta;
        if (!TryGetLugar(destino, out hasta)) return false;

        Vector3 a, b;
        if (!AjustarAlNavMesh(desde, out a) || !AjustarAlNavMesh(hasta, out b))
        {
            Debug.LogError("RutaCampus: no hay NavMesh cerca de los puntos. ¿Ya hiciste Bake en CampusNav y guardaste la escena?");
            return false;
        }

        var camino = new NavMeshPath();
        if (!NavMesh.CalculatePath(a, b, NavMesh.AllAreas, camino) || camino.corners.Length == 0)
        {
            Debug.LogError("RutaCampus: Unity no pudo calcular un camino hacia '" + destino + "'.");
            return false;
        }

        esquinas.AddRange(camino.corners);
        ultimaPosUsuario = desde;

        float metros = Longitud;
        if (usuario == null)
        {
            if (camino.status != NavMeshPathStatus.PathComplete)
                Debug.LogWarning("RutaCampus: la ruta es parcial (no llega completa al destino). Estado: " + camino.status);
            Debug.Log("Ruta " + origen + " → " + destino + ": " + metros.ToString("F0") + " m, "
                      + Mathf.Max(0, esquinas.Count - 2) + " giros, ~" + (metros / velocidadCaminata / 60f).ToString("F1") + " min caminando.");
        }
        else if (metros <= radioLlegada)
        {
            HaLlegado = true;
            esquinas.Clear();
            Debug.Log("Llegaste a " + destino + ".");
            if (Llegada != null) Llegada();
        }
        return true;
    }

    /// <summary>Posición en mundo de un lugar del campus por su nombre.</summary>
    public bool TryGetLugar(string nombre, out Vector3 posicion)
    {
        posicion = Vector3.zero;
        if (campus == null) campus = FindObjectOfType<CampusPOIs>();
        if (campus == null)
        {
            Debug.LogError("RutaCampus: no encuentro ningún objeto con el script CampusPOIs en la escena.");
            return false;
        }
        if (!campus.TryGetPosicion(nombre, out posicion))
        {
            Debug.LogError("RutaCampus: el lugar '" + nombre + "' no existe en campus_pois.json.");
            return false;
        }
        return true;
    }

    /// <summary>Igual que TryGetLugar, pero ya ajustado al lugar caminable más cercano del NavMesh.</summary>
    public bool TryGetPuntoNavegable(string nombre, out Vector3 punto)
    {
        punto = Vector3.zero;
        Vector3 lugar;
        return TryGetLugar(nombre, out lugar) && AjustarAlNavMesh(lugar, out punto);
    }

    /// <summary>Lleva un punto al lugar caminable más cercano del NavMesh.</summary>
    bool AjustarAlNavMesh(Vector3 punto, out Vector3 resultado)
    {
        NavMeshHit hit;
        if (NavMesh.SamplePosition(punto, out hit, radioBusqueda, NavMesh.AllAreas))
        {
            resultado = hit.position;
            return true;
        }
        resultado = punto;
        return false;
    }

    void OnDrawGizmos()
    {
        if (esquinas.Count < 2) return;

        var puntos = new Vector3[esquinas.Count];
        for (int i = 0; i < puntos.Length; i++) puntos[i] = esquinas[i] + Vector3.up * 0.5f;

#if UNITY_EDITOR
        Handles.color = new Color(0.1f, 1f, 0.3f);
        Handles.DrawAAPolyLine(8f, puntos);
        Handles.Label(puntos[puntos.Length - 1] + Vector3.up * 4f,
                      "Destino: " + destino + " (" + Longitud.ToString("F0") + " m)");
#endif
        Gizmos.color = Color.green;
        Gizmos.DrawSphere(puntos[0], 2.5f);
        Gizmos.color = Color.red;
        Gizmos.DrawSphere(puntos[puntos.Length - 1], 2.5f);
    }
}

#if UNITY_EDITOR
/// <summary>Dibuja el campo [LugarCampus] como lista desplegable (solo existe en el editor).</summary>
[CustomPropertyDrawer(typeof(LugarCampusAttribute))]
public class LugarCampusDrawer : PropertyDrawer
{
    static TextAsset jsonEnCache;
    static int hashEnCache;
    static string[] nombresEnCache;

    static string[] Nombres()
    {
        var campus = UnityEngine.Object.FindObjectOfType<CampusPOIs>();
        if (campus == null || campus.json == null) return null;

        // Se vuelve a leer el JSON si cambió su contenido (por ejemplo al agregar lugares nuevos)
        string texto = campus.json.text;
        int hash = texto.GetHashCode();
        if (campus.json != jsonEnCache || hash != hashEnCache || nombresEnCache == null)
        {
            var datos = JsonUtility.FromJson<CampusPOIs.Datos>(texto);
            if (datos == null || datos.pois == null) return null;
            // Primero los lugares propios (tipo "destino"), luego el resto por cercanía al centro del campus
            nombresEnCache = datos.pois
                .OrderBy(p => p.tipo == "destino" ? 0 : 1)
                .ThenBy(p => p.x * p.x + p.z * p.z)
                .Select(p => p.nombre)
                .Distinct()
                .ToArray();
            jsonEnCache = campus.json;
            hashEnCache = hash;
        }
        return nombresEnCache;
    }

    public override void OnGUI(Rect posicion, SerializedProperty propiedad, GUIContent etiqueta)
    {
        string[] nombres = Nombres();
        if (nombres == null || nombres.Length == 0)
        {
            // Sin datos todavía: campo de texto normal
            propiedad.stringValue = EditorGUI.TextField(posicion, etiqueta, propiedad.stringValue);
            return;
        }

        int actual = System.Array.IndexOf(nombres, propiedad.stringValue);
        EditorGUI.BeginChangeCheck();
        int nuevo = EditorGUI.Popup(posicion, etiqueta.text, Mathf.Max(0, actual), nombres);
        if (EditorGUI.EndChangeCheck()) propiedad.stringValue = nombres[nuevo];
    }
}
#endif
