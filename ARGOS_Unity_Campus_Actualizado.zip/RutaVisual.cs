using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

/// <summary>
/// Dibuja la ruta calculada por RutaCampus como una cinta pegada al suelo con flechas (>) que avanzan hacia el destino.
/// Va en el mismo objeto que RutaCampus (RutaPrueba). Solo dibuja; no calcula nada.
/// </summary>
public class RutaVisual : MonoBehaviour
{
    [Header("Referencias")]
    [Tooltip("Si se deja vacío usa el RutaCampus del mismo objeto.")]
    public RutaCampus ruta;
    [Tooltip("Material con shader Unlit/Transparent (opcional en el editor, recomendado para el build en Quest).")]
    public Material material;

    [Header("Apariencia")]
    public Color color = new Color(0.1f, 0.9f, 0.45f, 1f);
    [Tooltip("Ancho de la cinta en metros.")]
    public float ancho = 1.0f;
    [Tooltip("Separación entre flechas en metros.")]
    public float metrosPorFlecha = 1.6f;
    [Tooltip("Velocidad a la que avanzan las flechas (m/s).")]
    public float velocidad = 2.0f;
    [Tooltip("Qué tan arriba del suelo flota la cinta (m), para que no parpadee con el piso.")]
    public float alturaSobreSuelo = 0.2f;

    LineRenderer linea;
    Material matEnUso;
    Texture2D textura;
    Vector3[] ultimas = new Vector3[0];
    float desplazamiento;

    void Awake()
    {
        if (ruta == null) ruta = GetComponent<RutaCampus>();
        if (ruta == null) ruta = FindObjectOfType<RutaCampus>();

        textura = CrearTexturaFlecha(color);

        if (material != null)
        {
            matEnUso = new Material(material);   // copia: no modifica tu material del proyecto
        }
        else
        {
            Shader sh = Shader.Find("Unlit/Transparent");
            if (sh == null) sh = Shader.Find("Sprites/Default");
            if (sh == null)
            {
                Debug.LogError("RutaVisual: no encuentro un shader para dibujar las flechas. Asigna un material Unlit/Transparent.");
                enabled = false;
                return;
            }
            matEnUso = new Material(sh);
        }
        matEnUso.mainTexture = textura;
        matEnUso.mainTextureScale = new Vector2(1f / metrosPorFlecha, 1f);

        // La cinta vive en un objeto hijo acostado (mirando hacia arriba) para que se vea plana sobre el suelo
        var go = new GameObject("Cinta de ruta");
        go.transform.SetParent(transform, false);
        go.transform.rotation = Quaternion.Euler(90f, 0f, 0f);

        linea = go.AddComponent<LineRenderer>();
        linea.useWorldSpace = true;
        linea.alignment = LineAlignment.TransformZ;
        linea.textureMode = LineTextureMode.Tile;
        linea.widthMultiplier = ancho;
        linea.numCornerVertices = 3;
        linea.numCapVertices = 0;
        linea.shadowCastingMode = ShadowCastingMode.Off;
        linea.receiveShadows = false;
        linea.sharedMaterial = matEnUso;
        linea.positionCount = 0;
    }

    void Update()
    {
        if (ruta == null || linea == null) return;

        if (HuboCambio(ruta.Esquinas)) Redibujar(ruta.Esquinas);

        if (linea.positionCount > 1)
        {
            // Mover la textura hacia atrás hace que las flechas avancen hacia el destino
            desplazamiento -= velocidad / metrosPorFlecha * Time.deltaTime;
            desplazamiento -= Mathf.Floor(desplazamiento);
            matEnUso.mainTextureOffset = new Vector2(desplazamiento, 0f);
        }
    }

    bool HuboCambio(IReadOnlyList<Vector3> esquinas)
    {
        if (esquinas.Count != ultimas.Length) return true;
        for (int i = 0; i < esquinas.Count; i++)
            if (Vector3.Distance(esquinas[i], ultimas[i]) > 0.001f) return true;
        return false;
    }

    void Redibujar(IReadOnlyList<Vector3> esquinas)
    {
        ultimas = new Vector3[esquinas.Count];
        var puntos = new Vector3[esquinas.Count];
        for (int i = 0; i < esquinas.Count; i++)
        {
            ultimas[i] = esquinas[i];
            puntos[i] = esquinas[i] + Vector3.up * alturaSobreSuelo;
        }
        linea.positionCount = puntos.Length;
        if (puntos.Length > 0) linea.SetPositions(puntos);
    }

    /// <summary>Crea una textura con una flecha tipo chevron (>) apuntando en la dirección de la línea.</summary>
    static Texture2D CrearTexturaFlecha(Color c)
    {
        const int w = 128, h = 64;
        var tex = new Texture2D(w, h, TextureFormat.RGBA32, false);
        tex.wrapMode = TextureWrapMode.Repeat;
        tex.filterMode = FilterMode.Bilinear;

        var pix = new Color32[w * h];
        byte r = (byte)(c.r * 255f), g = (byte)(c.g * 255f), b = (byte)(c.b * 255f);
        for (int y = 0; y < h; y++)
        {
            float v = (y + 0.5f) / h;
            float dv = Mathf.Abs(v - 0.5f);
            float centro = 0.80f - dv * 0.9f;          // la punta (v = 0.5) queda más adelante que los brazos
            for (int x = 0; x < w; x++)
            {
                float u = (x + 0.5f) / w;
                float a = dv <= 0.42f ? Mathf.Clamp01((0.075f - Mathf.Abs(u - centro)) / 0.025f) : 0f;
                pix[y * w + x] = new Color32(r, g, b, (byte)(a * 255f));
            }
        }
        tex.SetPixels32(pix);
        tex.Apply();
        return tex;
    }

    void OnDestroy()
    {
        if (textura != null) Destroy(textura);
        if (matEnUso != null) Destroy(matEnUso);
    }
}
