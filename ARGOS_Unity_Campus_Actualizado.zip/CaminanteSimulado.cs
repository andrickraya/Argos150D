using UnityEngine;
using UnityEngine.AI;

/// <summary>
/// Usuario de PRUEBA para el editor: aparece en el Origen de RutaCampus y camina solo hasta el Destino
/// siguiendo el NavMesh. Sirve para comprobar el seguimiento en vivo sin necesidad del visor.
/// En el Quest este objeto no se usa: ahí el "usuario" es la cabeza del jugador.
/// </summary>
[RequireComponent(typeof(NavMeshAgent))]
public class CaminanteSimulado : MonoBehaviour
{
    [Tooltip("Si se deja vacío usa el RutaCampus de la escena.")]
    public RutaCampus ruta;
    [Tooltip("Multiplicador de velocidad para probar rápido (1 = caminata real, 1.4 m/s).")]
    public float aceleracion = 5f;

    NavMeshAgent agente;

    void Start()
    {
        agente = GetComponent<NavMeshAgent>();
        if (ruta == null) ruta = FindObjectOfType<RutaCampus>();
        if (ruta == null)
        {
            Debug.LogError("CaminanteSimulado: no encuentro ningún RutaCampus en la escena.");
            enabled = false;
            return;
        }

        Vector3 inicio, fin;
        if (!ruta.TryGetPuntoNavegable(ruta.origen, out inicio) || !ruta.TryGetPuntoNavegable(ruta.destino, out fin))
        {
            enabled = false;
            return;
        }

        agente.speed = ruta.velocidadCaminata * aceleracion;
        agente.acceleration = 100f;          // arranca y frena sin rampa lenta
        agente.Warp(inicio);
        agente.SetDestination(fin);
    }
}
