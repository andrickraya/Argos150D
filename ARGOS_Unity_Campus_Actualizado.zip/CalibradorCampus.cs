using UnityEngine;
using UnityEngine.XR;

/// <summary>
/// Alinea el campus virtual con el mundo real.
/// El Quest no tiene GPS, así que el usuario se para físicamente en un lugar conocido del campus
/// (por ejemplo Puerta 3), mira hacia otro lugar de referencia (por ejemplo la Biblioteca) y presiona el botón A.
/// El script mueve y gira el Camera Rig (no el campus) para que la cabeza del usuario quede exactamente
/// en ese punto del mapa y orientada hacia esa referencia. Se puede repetir las veces que haga falta.
///
/// Sin controles: se puede calibrar solo tras unos segundos (campo "Calibrar Automatico En Segundos").
/// En el editor (sin visor): clic en la vista Game y tecla C.
/// </summary>
public class CalibradorCampus : MonoBehaviour
{
    [Header("Referencias")]
    [Tooltip("El objeto raíz del visor: [BuildingBlock] Camera Rig.")]
    public Transform rig;
    [Tooltip("La cabeza del usuario: CenterEyeAnchor (dentro del Camera Rig).")]
    public Transform cabeza;
    [Tooltip("El objeto que tiene RutaCampus (RutaPrueba). La ruta se activa al calibrar.")]
    public RutaCampus ruta;
    [Tooltip("Objeto Campus (con CampusPOIs). Si se deja vacío se busca solo.")]
    public CampusPOIs campus;

    [Header("Punto de calibración")]
    [Tooltip("Lugar donde te paras físicamente para calibrar.")]
    [LugarCampus] public string estoyEn = "Puerta 3";
    [Tooltip("Lugar hacia el que miras al calibrar. Mientras más lejos (25 m o más), más precisa la orientación.")]
    [LugarCampus] public string miroHacia = "Library";

    [Header("Sin controles (opcional)")]
    [Tooltip("Si es mayor que 0, calibra solo esa cantidad de segundos después de abrir la app. Útil si no tienes controles. 0 = desactivado.")]
    public float calibrarAutomaticoEnSegundos = 0f;

    [Header("Avisos sonoros (para saber qué pasó sin ver la consola)")]
    [Tooltip("Pitido agudo = calibró. Pitido grave y largo = falló. Tono muy agudo = llegaste al destino.")]
    public bool sonidos = true;

    [Header("Modelo 3D en el visor")]
    [Tooltip("Objetos cuyo modelo 3D se oculta en el visor para no tapar la cámara de paso (Campus y CampusNav).")]
    public GameObject[] modelosAOcultar;
    [Tooltip("Ocultarlos también al probar en el editor.")]
    public bool ocultarEnEditor = false;

    public bool Calibrado { get; private set; }

    bool botonAntes;
    float tiempoDesdeInicio;
    bool autoHecho;
    AudioClip tonoOk, tonoError, tonoLlegada;

    void Awake()
    {
        // La ruta no empieza hasta que el usuario calibre; si no, saldría desde un punto cualquiera.
        if (ruta != null) ruta.enabled = false;
    }

    void Start()
    {
        if (campus == null) campus = FindObjectOfType<CampusPOIs>();
        if (ruta != null) ruta.Llegada += AlLlegar;

        bool ocultar = ocultarEnEditor;
#if !UNITY_EDITOR
        ocultar = true;
#endif
        if (ocultar && modelosAOcultar != null)
        {
            foreach (var go in modelosAOcultar)
            {
                if (go == null) continue;
                foreach (var r in go.GetComponentsInChildren<Renderer>(true)) r.enabled = false;
            }
        }
    }

    void Update()
    {
        bool presionado = false;
        InputDevice mano = InputDevices.GetDeviceAtXRNode(XRNode.RightHand);
        bool valor;
        if (mano.isValid && mano.TryGetFeatureValue(CommonUsages.primaryButton, out valor)) presionado = valor;

        if (presionado && !botonAntes)
        {
            if (Intentar(true)) Vibrar(mano);
        }
        botonAntes = presionado;

        if (calibrarAutomaticoEnSegundos > 0f && !autoHecho)
        {
            tiempoDesdeInicio += Time.deltaTime;
            if (tiempoDesdeInicio >= calibrarAutomaticoEnSegundos)
            {
                // Si falla (por ejemplo mirando hacia el piso), reintenta cada segundo hasta lograrlo
                if (Intentar(false)) autoHecho = true;
                else tiempoDesdeInicio = calibrarAutomaticoEnSegundos - 1f;
            }
        }

#if ENABLE_LEGACY_INPUT_MANAGER
        if (Input.GetKeyDown(KeyCode.C)) Calibrar();
#endif
    }

    /// <summary>Calibra con la posición y mirada actuales del usuario.</summary>
    [ContextMenu("Calibrar ahora")]
    public bool Calibrar()
    {
        return Intentar(true);
    }

    /// <summary>Intenta calibrar y avisa con un pitido. Con avisarFallo = false solo suena si funciona.</summary>
    bool Intentar(bool avisarFallo)
    {
        bool ok = CalibrarInterno();
        if (ok) Sonar(ref tonoOk, 880f, 0.25f);
        else if (avisarFallo) Sonar(ref tonoError, 220f, 0.6f);
        return ok;
    }

    bool CalibrarInterno()
    {
        if (rig == null || cabeza == null)
        {
            Debug.LogError("CalibradorCampus: faltan las referencias Rig y Cabeza.");
            return false;
        }
        if (campus == null) campus = FindObjectOfType<CampusPOIs>();
        Vector3 aqui, referencia;
        if (campus == null || !campus.TryGetPosicion(estoyEn, out aqui) || !campus.TryGetPosicion(miroHacia, out referencia))
        {
            Debug.LogError("CalibradorCampus: no encuentro '" + estoyEn + "' o '" + miroHacia + "' en campus_pois.json.");
            return false;
        }

        // Rumbo (grados, 0 = norte, 90 = este) que debe tener la mirada del usuario
        Vector3 haciaRef = referencia - aqui;
        haciaRef.y = 0f;
        if (haciaRef.magnitude < 5f)
        {
            Debug.LogWarning("CalibradorCampus: '" + miroHacia + "' está a menos de 5 m de '" + estoyEn + "'. Elige una referencia más lejana.");
            return false;
        }
        float rumboDeseado = Mathf.Atan2(haciaRef.x, haciaRef.z) * Mathf.Rad2Deg;

        // Rumbo actual de la mirada (sin inclinación arriba/abajo)
        Vector3 f = cabeza.forward;
        f.y = 0f;
        if (f.magnitude < 0.1f) return false;   // mirando casi vertical: no se puede medir
        float rumboActual = Mathf.Atan2(f.x, f.z) * Mathf.Rad2Deg;

        // 1) girar el rig alrededor de la cabeza  2) trasladarlo para que la cabeza caiga en el punto conocido
        rig.RotateAround(cabeza.position, Vector3.up, Mathf.DeltaAngle(rumboActual, rumboDeseado));
        Vector3 desplazamiento = aqui - cabeza.position;
        desplazamiento.y = 0f;
        rig.position += desplazamiento;

        Calibrado = true;
        if (ruta != null) ruta.enabled = true;
        Debug.Log("Calibrado en " + estoyEn + " mirando hacia " + miroHacia + " (rumbo " + rumboDeseado.ToString("F0") + "°).");
        return true;
    }

    void AlLlegar()
    {
        Sonar(ref tonoLlegada, 1320f, 0.5f);
    }

    void Sonar(ref AudioClip clip, float frecuencia, float segundos)
    {
        if (!sonidos || cabeza == null) return;
        if (clip == null) clip = CrearTono(frecuencia, segundos);
        AudioSource.PlayClipAtPoint(clip, cabeza.position, 1f);
    }

    /// <summary>Genera un tono simple (sin necesidad de archivos de audio).</summary>
    static AudioClip CrearTono(float frecuencia, float segundos)
    {
        const int muestrasPorSegundo = 44100;
        int n = (int)(muestrasPorSegundo * segundos);
        var datos = new float[n];
        for (int i = 0; i < n; i++)
        {
            float t = (float)i / muestrasPorSegundo;
            float suave = Mathf.Min(1f, i / 400f) * Mathf.Min(1f, (n - i) / 2000f);   // evita chasquidos al inicio y al final
            datos[i] = Mathf.Sin(2f * Mathf.PI * frecuencia * t) * 0.5f * suave;
        }
        var clip = AudioClip.Create("tono", n, 1, muestrasPorSegundo, false);
        clip.SetData(datos, 0);
        return clip;
    }

    void OnDestroy()
    {
        if (ruta != null) ruta.Llegada -= AlLlegar;
    }

    static void Vibrar(InputDevice mano)
    {
        HapticCapabilities capacidades;
        if (mano.TryGetHapticCapabilities(out capacidades) && capacidades.supportsImpulse)
            mano.SendHapticImpulse(0u, 0.6f, 0.2f);
    }
}
