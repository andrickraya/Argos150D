using System;
using System.Collections.Generic;
using UnityEngine;
#if UNITY_EDITOR
using UnityEditor;
#endif

/// <summary>
/// Carga campus_pois.json y deja los lugares disponibles como destinos de navegación.
/// También los dibuja en la vista Scene (esferas + nombre) para comprobar que el mapa quedó alineado.
/// Úsalo en el MISMO objeto padre (posición 0,0,0) donde pongas campus_suelo y campus_edificios.
/// </summary>
public class CampusPOIs : MonoBehaviour
{
    [Serializable] public class Poi
    {
        public string id;
        public string nombre;
        public string tipo;      // edificio, camino, acceso, cafe, ...
        public float x;          // metros hacia el este
        public float z;          // metros hacia el norte
        public float altura;
    }
    [Serializable] public class Datos { public Poi[] pois; }

    [Tooltip("Arrastra aquí campus_pois.json")]
    public TextAsset json;
    public bool dibujarEnEscena = true;
    public float radioEsfera = 2.5f;
    [Tooltip("Solo dibujar este tipo (vacío = todos)")]
    public string filtroTipo = "";

    Poi[] pois;
    Dictionary<string, Poi> porNombre;

    void Awake() { Cargar(); }

    void Cargar()
    {
        if (json == null) return;
        pois = JsonUtility.FromJson<Datos>(json.text).pois;
        porNombre = new Dictionary<string, Poi>();
        foreach (var p in pois)
            if (!porNombre.ContainsKey(p.nombre)) porNombre.Add(p.nombre, p);
    }

    /// <summary>Posición en mundo de un lugar por su nombre (ej. "Library", "La Karpa", "Puerta 3").</summary>
    public bool TryGetPosicion(string nombre, out Vector3 posicion)
    {
        if (porNombre == null) Cargar();
        if (porNombre != null && porNombre.TryGetValue(nombre, out var p))
        {
            posicion = transform.TransformPoint(new Vector3(p.x, 0f, p.z));
            return true;
        }
        posicion = Vector3.zero;
        return false;
    }

    public IEnumerable<Poi> Lugares()
    {
        if (pois == null) Cargar();
        return pois ?? new Poi[0];
    }

    void OnDrawGizmos()
    {
        if (!dibujarEnEscena) return;
        if (pois == null) Cargar();
        if (pois == null) return;

        foreach (var p in pois)
        {
            if (!string.IsNullOrEmpty(filtroTipo) && p.tipo != filtroTipo) continue;
            Vector3 pos = transform.TransformPoint(new Vector3(p.x, p.altura, p.z));
            Gizmos.color = p.tipo == "acceso" ? Color.yellow : (p.tipo == "edificio" ? Color.red : Color.cyan);
            Gizmos.DrawSphere(pos, radioEsfera);
#if UNITY_EDITOR
            Handles.Label(pos + Vector3.up * (radioEsfera + 1f), p.nombre);
#endif
        }
    }
}
